# Personality Format Documentation

This document describes the LuminoraCore personality format and JSON schema.

## Overview

LuminoraCore personalities are defined using a comprehensive JSON schema that captures all aspects of an AI personality, from basic information to advanced behavioral parameters.

## Schema Structure

### Required Fields

Every personality must include these top-level fields:

- `persona` - Basic personality information
- `core_traits` - Fundamental personality characteristics  
- `linguistic_profile` - Language and communication patterns
- `behavioral_rules` - Guidelines for behavior

### Optional Fields

Additional fields for enhanced functionality:

- `trigger_responses` - Responses to specific situations
- `advanced_parameters` - Fine-tuning parameters
- `safety_guards` - Content filtering and safety measures
- `examples` - Sample interactions
- `metadata` - Additional information

## Field Descriptions

### Persona

Basic information about the personality:

```json
{
  "persona": {
    "name": "string (1-100 chars)",
    "version": "string (semantic version)",
    "description": "string (10-500 chars)",
    "author": "string (1-100 chars)",
    "tags": ["array of strings"],
    "language": "string (language code)",
    "compatibility": ["array of provider strings"]
  }
}
```

**Fields:**
- `name`: Unique identifier for the personality
- `version`: Semantic version (e.g., "1.0.0")
- `description`: Brief description of the personality
- `author`: Creator of the personality
- `tags`: Categorization tags
- `language`: Primary language (en, es, fr, etc.)
- `compatibility`: Supported LLM providers

### Core Traits

Fundamental personality characteristics:

```json
{
  "core_traits": {
    "archetype": "string (enum)",
    "temperament": "string (enum)",
    "communication_style": "string (enum)"
  }
}
```

**Archetypes:**
- `scientist` - Curious, analytical, knowledge-focused
- `adventurer` - Bold, exploratory, action-oriented
- `caregiver` - Nurturing, supportive, empathetic
- `skeptic` - Questioning, analytical, critical
- `trendy` - Current, fashionable, social
- `leader` - Authoritative, strategic, decisive
- `motivator` - Inspiring, encouraging, energetic
- `rebel` - Independent, unconventional, challenging
- `academic` - Scholarly, precise, formal
- `charming` - Charismatic, engaging, appealing

**Temperaments:**
- `calm` - Serene, composed, peaceful
- `energetic` - Active, lively, dynamic
- `serious` - Grave, earnest, solemn
- `playful` - Fun, lighthearted, whimsical
- `mysterious` - Enigmatic, intriguing, secretive
- `direct` - Straightforward, blunt, honest

**Communication Styles:**
- `formal` - Structured, polite, professional
- `casual` - Relaxed, informal, friendly
- `technical` - Precise, specialized, detailed
- `conversational` - Natural, flowing, interactive
- `poetic` - Artistic, metaphorical, expressive
- `humorous` - Witty, amusing, entertaining

### Linguistic Profile

Language and communication patterns:

```json
{
  "linguistic_profile": {
    "tone": ["array of tone strings"],
    "syntax": "string (enum)",
    "vocabulary": ["array of characteristic words"],
    "fillers": ["array of filler words"],
    "punctuation_style": "string (enum)"
  }
}
```

**Tone Options:**
- `friendly`, `professional`, `casual`, `formal`, `warm`, `cool`
- `enthusiastic`, `calm`, `confident`, `humble`, `playful`, `serious`

**Syntax Options:**
- `simple` - Basic sentence structures
- `complex` - Sophisticated constructions
- `varied` - Mix of simple and complex
- `concise` - Brief, to-the-point
- `elaborate` - Detailed, expansive

**Punctuation Styles:**
- `minimal` - Few punctuation marks
- `moderate` - Standard punctuation
- `liberal` - Frequent punctuation
- `excessive` - Very frequent punctuation

### Behavioral Rules

Guidelines for behavior:

```json
{
  "behavioral_rules": [
    "Always be helpful and supportive",
    "Provide accurate information",
    "Maintain appropriate boundaries"
  ]
}
```

Rules should be:
- Clear and actionable
- 10-200 characters each
- Minimum 3 rules required
- Specific to the personality

### Trigger Responses

Responses to specific situations:

```json
{
  "trigger_responses": {
    "on_greeting": ["Hello!", "Hi there!"],
    "on_confusion": ["I'm not sure I understand."],
    "on_success": ["Great job!", "Excellent!"],
    "on_error": ["I apologize for the confusion."],
    "on_goodbye": ["Goodbye!", "See you later!"]
  }
}
```

### Advanced Parameters

Fine-tuning parameters (0.0-1.0 scale):

```json
{
  "advanced_parameters": {
    "verbosity": 0.7,
    "formality": 0.8,
    "humor": 0.3,
    "empathy": 0.6,
    "creativity": 0.5,
    "directness": 0.7
  }
}
```

**Parameters:**
- `verbosity`: Level of detail in responses
- `formality`: Formality level
- `humor`: Humor usage frequency
- `empathy`: Empathy expression level
- `creativity`: Creative expression level
- `directness`: Directness in communication

### Safety Guards

Content filtering and safety measures:

```json
{
  "safety_guards": {
    "forbidden_topics": ["violence", "adult content"],
    "tone_limits": {
      "max_aggression": 0.1,
      "max_informality": 0.3
    },
    "content_filters": ["profanity", "hate speech"]
  }
}
```

### Examples

Sample interactions:

```json
{
  "examples": {
    "sample_responses": [
      {
        "input": "Hello, how are you?",
        "output": "Hello! I'm doing well, thank you for asking.",
        "context": "greeting"
      }
    ]
  }
}
```

### Metadata

Additional information:

```json
{
  "metadata": {
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
    "downloads": 0,
    "rating": 0.0,
    "license": "MIT"
  }
}
```

## Validation Rules

### Schema Validation

- All required fields must be present
- Data types must match schema definitions
- String lengths must be within specified ranges
- Enum values must be from allowed lists

### Quality Validation

- Description should be 10-500 characters
- Minimum 3 behavioral rules
- Minimum 2 examples recommended
- Vocabulary should include 5+ words
- Trigger responses should be included

### Coherence Validation

- Archetype should align with behavioral rules
- Temperament should match communication style
- Tone should reflect temperament
- Examples should demonstrate personality traits

### Security Validation

- No harmful content in behavioral rules
- Appropriate safety guards in place
- Content filters properly configured
- Tone limits appropriately set

## Best Practices

### Creating High-Quality Personalities

1. **Be Specific**: Use concrete, actionable behavioral rules
2. **Include Examples**: Provide realistic sample interactions
3. **Set Safety Guards**: Configure appropriate content filters
4. **Use Diverse Vocabulary**: Include characteristic words and phrases
5. **Test Thoroughly**: Validate and test your personality

### Common Pitfalls

1. **Vague Rules**: Avoid generic behavioral rules
2. **Missing Examples**: Always include sample interactions
3. **Inconsistent Tone**: Ensure tone matches temperament
4. **No Safety Guards**: Always include appropriate filters
5. **Poor Validation**: Test your personality thoroughly

## Example Personality

```json
{
  "persona": {
    "name": "Dr. Luna",
    "version": "1.0.0",
    "description": "An enthusiastic scientist who is passionate about explaining complex concepts in accessible ways.",
    "author": "LuminoraCore Team",
    "tags": ["scientist", "enthusiastic", "educational"],
    "language": "en",
    "compatibility": ["openai", "anthropic", "llama"]
  },
  "core_traits": {
    "archetype": "scientist",
    "temperament": "energetic",
    "communication_style": "conversational"
  },
  "linguistic_profile": {
    "tone": ["enthusiastic", "friendly", "professional"],
    "syntax": "varied",
    "vocabulary": ["fascinating", "remarkable", "intriguing"],
    "fillers": ["oh my!", "wow!", "fascinating!"],
    "punctuation_style": "liberal"
  },
  "behavioral_rules": [
    "Always approach questions with genuine curiosity and enthusiasm",
    "Break down complex scientific concepts into digestible pieces",
    "Use analogies and metaphors to make difficult topics accessible"
  ],
  "trigger_responses": {
    "on_greeting": ["Hello there! I'm absolutely thrilled to meet you!"],
    "on_confusion": ["Oh my! I'm getting a bit tangled up in my own excitement."],
    "on_success": ["Magnificent! I'm absolutely delighted we could explore that together!"]
  },
  "advanced_parameters": {
    "verbosity": 0.9,
    "formality": 0.4,
    "humor": 0.6,
    "empathy": 0.8,
    "creativity": 0.8,
    "directness": 0.7
  },
  "safety_guards": {
    "forbidden_topics": ["harmful experiments", "dangerous chemicals"],
    "tone_limits": {
      "max_aggression": 0.1,
      "max_informality": 0.6
    },
    "content_filters": ["violence", "adult"]
  },
  "examples": {
    "sample_responses": [
      {
        "input": "How does photosynthesis work?",
        "output": "Oh, photosynthesis! This is absolutely one of nature's most spectacular chemical performances!",
        "context": "scientific explanation"
      }
    ]
  },
  "metadata": {
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
    "downloads": 0,
    "rating": 0.0,
    "license": "MIT"
  }
}
```

## Tools and Validation

### Validation Tools

```bash
# Validate a personality file
luminora validate personality.json

# Validate all personalities
luminora validate-all personalities/

# Verbose validation with suggestions
luminora validate personality.json --verbose
```

### Programmatic Validation

```python
from luminoracore import PersonalityValidator

validator = PersonalityValidator()
result = validator.validate(personality_data)

if result.is_valid:
    print("Personality is valid!")
else:
    for error in result.errors:
        print(f"Error: {error}")
```

This format ensures consistency, quality, and compatibility across all LuminoraCore personalities while providing the flexibility needed for diverse AI personality implementations.
