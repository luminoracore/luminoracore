# Formato de Personalidades

Esta guía detalla el formato JSON completo para crear personalidades en LuminoraCore.

## Estructura General

Una personalidad en LuminoraCore es un archivo JSON que sigue un schema estricto. La estructura básica es:

```json
{
  "persona": { ... },
  "core_traits": { ... },
  "linguistic_profile": { ... },
  "behavioral_rules": [ ... ],
  "trigger_responses": { ... },
  "advanced_parameters": { ... },
  "safety_guards": { ... },
  "examples": { ... },
  "metadata": { ... }
}
```

## Campos Obligatorios

### 1. persona
Información básica de la personalidad.

```json
{
  "persona": {
    "name": "Dr. Luna",
    "version": "1.0.0",
    "description": "Una científica curiosa y entusiasta...",
    "author": "PersonaCore Team",
    "tags": ["educativo", "científico"],
    "language": "es",
    "compatibility": ["openai", "anthropic", "universal"]
  }
}
```

**Campos:**
- `name`: Nombre único (2-50 caracteres)
- `version`: Versión semántica (formato: x.y.z)
- `description`: Descripción clara (10-500 caracteres)
- `author`: Nombre del creador (2-100 caracteres)
- `tags`: Lista de etiquetas para categorización
- `language`: Código de idioma (es, en, fr, etc.)
- `compatibility`: Proveedores compatibles

### 2. core_traits
Rasgos fundamentales de la personalidad.

```json
{
  "core_traits": {
    "archetype": "El Sabio Entusiasta",
    "temperament": "Optimista y Curioso",
    "communication_style": "Claro, Analógico, Detallado"
  }
}
```

**Campos:**
- `archetype`: Arquetipo psicológico (5-100 caracteres)
- `temperament`: Descripción del temperamento (10-300 caracteres)
- `communication_style`: Cómo se comunica (10-300 caracteres)

### 3. linguistic_profile
Características del lenguaje y comunicación.

```json
{
  "linguistic_profile": {
    "tone": ["asombrado", "pedagógico", "alentador"],
    "syntax": "formal",
    "vocabulary": ["¡Fascinante!", "Permíteme explicarte..."],
    "fillers": ["Vaya...", "Interesante pregunta..."],
    "punctuation_style": "expresivo"
  }
}
```

**Campos:**
- `tone`: Lista de tonos de voz (1-5 elementos)
- `syntax`: Estilo de construcción de oraciones
- `vocabulary`: Palabras características (3-20 elementos)
- `fillers`: Expresiones de relleno (1-10 elementos)
- `punctuation_style`: Uso de puntuación

### 4. behavioral_rules
Reglas específicas que guían el comportamiento.

```json
{
  "behavioral_rules": [
    "Nunca dice 'Es complicado'. Busca analogías simples",
    "Convierte errores en oportunidades de aprendizaje",
    "Siempre conecta conceptos abstractos con ejemplos reales"
  ]
}
```

**Requisitos:**
- Mínimo 3 reglas, máximo 15
- Cada regla: 10-200 caracteres
- Deben ser específicas y accionables

## Campos Opcionales

### 5. trigger_responses
Respuestas específicas para situaciones comunes.

```json
{
  "trigger_responses": {
    "on_greeting": [
      "¡Hola! ¿Listo para explorar algo nuevo?",
      "¡Buenos días! ¿Qué investigamos hoy?"
    ],
    "on_confusion": [
      "Vaya, desglosémoslo paso a paso...",
      "Permíteme intentarlo de otra forma"
    ],
    "on_success": [
      "¡Lo tienes! Es un placer ver cómo se enciende la comprensión",
      "¡Maravilloso! La curiosidad es el motor del descubrimiento"
    ],
    "on_error": [
      "Hmm, parece que tomamos un desvío. Volvamos al camino principal",
      "¡No hay problema! Los mejores científicos aprenden de sus 'experimentos fallidos'"
    ],
    "on_goodbye": [
      "¡Hasta la próxima aventura científica!",
      "¡Que tengas un día lleno de descubrimientos!"
    ]
  }
}
```

### 6. advanced_parameters
Configuración numérica de características.

```json
{
  "advanced_parameters": {
    "verbosity": 0.7,      // 0.0 = conciso, 1.0 = muy detallado
    "formality": 0.4,      // 0.0 = casual, 1.0 = formal
    "humor": 0.6,          // 0.0 = serio, 1.0 = muy humorístico
    "empathy": 0.8,        // 0.0 = frío, 1.0 = muy empático
    "creativity": 0.9,     // 0.0 = literal, 1.0 = muy creativo
    "directness": 0.6      // 0.0 = diplomático, 1.0 = directo
  }
}
```

**Todos los valores deben estar entre 0.0 y 1.0**

### 7. safety_guards
Configuración de seguridad y filtros.

```json
{
  "safety_guards": {
    "forbidden_topics": [
      "pseudociencia sin base",
      "teorías conspirativas"
    ],
    "tone_limits": {
      "max_sarcasm": 0.1,
      "max_aggression": 0.0,
      "max_negativity": 0.2
    },
    "content_filters": [
      "información médica que requiera profesional",
      "consejos peligrosos"
    ]
  }
}
```

### 8. examples
Ejemplos de interacciones típicas.

```json
{
  "examples": {
    "sample_responses": [
      {
        "input": "¿Cómo funciona la gravedad?",
        "output": "¡Fascinante pregunta! Imagínate que el espacio-tiempo es como una cama elástica...",
        "context": "Pregunta educativa básica"
      },
      {
        "input": "¿Qué es la fotosíntesis?",
        "output": "¡Qué maravilloso proceso! Es como si las plantas fueran las mejores chefs del mundo...",
        "context": "Pregunta sobre biología"
      }
    ]
  }
}
```

**Requisitos:**
- Mínimo 2 ejemplos, máximo 10
- Cada ejemplo debe tener `input`, `output` y `context`
- El `output` debe ser representativo de la personalidad

### 9. metadata
Información adicional sobre la personalidad.

```json
{
  "metadata": {
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z",
    "license": "MIT"
  }
}
```

## Validación

### Validación Básica

```bash
luminora validate mi_personalidad.json
```

### Validación Detallada

```bash
luminora validate mi_personalidad.json --detailed
```

### Validación Programática

```python
from luminoracore.tools.validator import PersonalityValidator

validator = PersonalityValidator()
report = validator.get_validation_report("mi_personalidad.json")

if report["valid"]:
    print("✓ Personalidad válida")
else:
    print("✗ Errores encontrados:")
    for error in report["errors"]:
        print(f"  - {error}")
```

## Errores Comunes

### 1. Campos Requeridos Faltantes
```json
// ❌ Incorrecto
{
  "persona": {
    "name": "Dr. Luna"
    // Falta version, description, etc.
  }
}

// ✅ Correcto
{
  "persona": {
    "name": "Dr. Luna",
    "version": "1.0.0",
    "description": "Una científica entusiasta...",
    "author": "PersonaCore Team",
    "tags": ["educativo"],
    "language": "es",
    "compatibility": ["universal"]
  }
}
```

### 2. Tipos de Datos Incorrectos
```json
// ❌ Incorrecto
{
  "advanced_parameters": {
    "verbosity": "alto"  // Debe ser número
  }
}

// ✅ Correcto
{
  "advanced_parameters": {
    "verbosity": 0.8  // Número entre 0.0 y 1.0
  }
}
```

### 3. Valores Fuera de Rango
```json
// ❌ Incorrecto
{
  "advanced_parameters": {
    "humor": 1.5  // Fuera del rango 0.0-1.0
  }
}

// ✅ Correcto
{
  "advanced_parameters": {
    "humor": 0.7  // Dentro del rango válido
  }
}
```

### 4. Vocabulario Insuficiente
```json
// ❌ Incorrecto
{
  "linguistic_profile": {
    "vocabulary": ["hola"]  // Mínimo 3 palabras
  }
}

// ✅ Correcto
{
  "linguistic_profile": {
    "vocabulary": ["hola", "gracias", "perfecto", "excelente"]
  }
}
```

## Mejores Prácticas

### 1. Nombres Descriptivos
- Usa nombres que reflejen la personalidad
- Evita nombres genéricos como "Asistente" o "Bot"

### 2. Descripciones Claras
- Sé específico sobre el propósito de la personalidad
- Incluye el contexto de uso

### 3. Vocabulario Característico
- Usa palabras que realmente usaría esta personalidad
- Incluye expresiones únicas y memorables

### 4. Reglas Específicas
- Evita reglas vagas como "Ser útil"
- Sé específico: "Siempre explicar conceptos con analogías del mundo real"

### 5. Ejemplos Representativos
- Los ejemplos deben mostrar la personalidad en acción
- Incluye diferentes tipos de interacciones

### 6. Parámetros Balanceados
- No todos los parámetros deben estar en extremos
- Considera cómo interactúan entre sí

## Templates y Ejemplos

### Template Básico
```bash
luminora init "Mi Personalidad" --interactive
```

### Personalidades de Referencia
Estudia las personalidades incluidas en LuminoraCore:
- `dr_luna.json` - Personalidad educativa
- `victoria_sterling.json` - Personalidad profesional
- `abuela_esperanza.json` - Personalidad empática

### Generador de Personalidades
Para personalidades complejas, considera usar el generador:

```python
from luminoracore.tools.blender import PersonalityBlender

# Mezclar personalidades existentes como base
blender = PersonalityBlender()
# ... crear personalidad híbrida
```

## Recursos Adicionales

- [Schema JSON Completo](../schema/personality.schema.json)
- [Ejemplos de Personalidades](../personalities/)
- [Mejores Prácticas](best_practices.md)
- [API Reference](api_reference.md)
