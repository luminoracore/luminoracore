# Tests for LuminoraCore CLI
