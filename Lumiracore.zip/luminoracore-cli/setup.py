"""Setup script for LuminoraCore CLI."""

from setuptools import setup, find_packages

setup()
