# Referencia de API

Documentación completa de la API de LuminoraCore.

## PersonaCore (Clase Principal)

### `PersonaCore(personalities_dir=None)`

Inicializa el motor principal de LuminoraCore.

**Parámetros:**
- `personalities_dir` (Path, opcional): Directorio personalizado de personalidades

**Ejemplo:**
```python
from luminoracore import PersonaCore

pc = PersonaCore()
pc = PersonaCore(Path("./mis_personas"))
```

### `load_persona(name: str) -> Dict[str, Any]`

Carga una personalidad por nombre.

**Parámetros:**
- `name` (str): Nombre de la personalidad (sin extensión .json)

**Retorna:**
- `Dict[str, Any]`: Personalidad cargada

**Excepciones:**
- `FileNotFoundError`: Si la personalidad no existe
- `ValidationError`: Si la personalidad no es válida

**Ejemplo:**
```python
personality = pc.load_persona("dr_luna")
```

### `validate_persona(personality: Union[Dict[str, Any], str]) -> bool`

Valida una personalidad.

**Parámetros:**
- `personality`: Personalidad como diccionario o ruta a archivo

**Retorna:**
- `bool`: True si es válida, False en caso contrario

**Ejemplo:**
```python
is_valid = pc.validate_persona("personalities/dr_luna.json")
is_valid = pc.validate_persona(personality_dict)
```

### `compile_for(provider: str, personality: Dict[str, Any], **kwargs) -> str`

Compila una personalidad para un proveedor específico.

**Parámetros:**
- `provider` (str): Proveedor objetivo (openai, anthropic, llama, mistral, universal)
- `personality` (Dict): Personalidad a compilar
- `**kwargs`: Parámetros adicionales para el compilador

**Retorna:**
- `str`: Prompt compilado

**Excepciones:**
- `ValueError`: Si el proveedor no es soportado

**Ejemplo:**
```python
prompt = pc.compile_for("openai", personality)
prompt = pc.compile_for("anthropic", personality, max_tokens=8000)
```

### `blend_personas(blend_config: Dict[str, float]) -> Dict[str, Any]`

Mezcla múltiples personalidades según los pesos especificados.

**Parámetros:**
- `blend_config` (Dict): Diccionario con nombres de personalidades y sus pesos

**Retorna:**
- `Dict[str, Any]`: Personalidad mezclada

**Excepciones:**
- `ValueError`: Si los pesos son inválidos o hay personalidades faltantes

**Ejemplo:**
```python
blend_config = {
    "dr_luna": 0.6,
    "capitan_garfio": 0.4
}
hybrid = pc.blend_personas(blend_config)
```

### `list_personalities() -> List[str]`

Lista todas las personalidades disponibles.

**Retorna:**
- `List[str]`: Lista de nombres de personalidades

**Ejemplo:**
```python
personalities = pc.list_personalities()
print(f"Encontradas {len(personalities)} personalidades")
```

### `get_personality_info(name: str) -> Dict[str, Any]`

Obtiene información básica de una personalidad.

**Parámetros:**
- `name` (str): Nombre de la personalidad

**Retorna:**
- `Dict[str, Any]`: Información básica

**Ejemplo:**
```python
info = pc.get_personality_info("dr_luna")
print(f"Autor: {info['author']}")
print(f"Tags: {info['tags']}")
```

### `ab_test(persona_a: str, persona_b: str, test_inputs: List[str], metric: str = "user_satisfaction", **kwargs) -> Dict[str, Any]`

Configura un test A/B entre dos personalidades.

**Parámetros:**
- `persona_a` (str): Nombre de la primera personalidad
- `persona_b` (str): Nombre de la segunda personalidad
- `test_inputs` (List[str]): Lista de inputs para probar
- `metric` (str): Métrica a evaluar
- `**kwargs`: Parámetros adicionales

**Retorna:**
- `Dict[str, Any]`: Resultados del test A/B

**Ejemplo:**
```python
results = pc.ab_test(
    "dr_luna",
    "prof_rigoberto",
    ["Explica la gravedad", "¿Cómo funciona un motor?"],
    "user_satisfaction"
)
```

## PersonalityValidator

### `PersonalityValidator(schema_path=None)`

Inicializa el validador de personalidades.

**Parámetros:**
- `schema_path` (Path, opcional): Ruta personalizada al schema JSON

**Ejemplo:**
```python
from luminoracore.tools.validator import PersonalityValidator

validator = PersonalityValidator()
```

### `validate(personality: Union[Dict[str, Any], str, Path]) -> bool`

Valida una personalidad completa.

**Parámetros:**
- `personality`: Personalidad como diccionario, ruta a archivo o contenido JSON

**Retorna:**
- `bool`: True si es válida

**Excepciones:**
- `ValidationError`: Si la personalidad no es válida
- `ValueError`: Si hay errores en el formato

**Ejemplo:**
```python
try:
    validator.validate("personalities/dr_luna.json")
    print("✓ Personalidad válida")
except Exception as e:
    print(f"✗ Error: {e}")
```

### `validate_schema_only(personality: Union[Dict[str, Any], str, Path]) -> bool`

Valida solo el schema JSON.

**Parámetros:**
- `personality`: Personalidad a validar

**Retorna:**
- `bool`: True si cumple el schema

**Ejemplo:**
```python
is_valid = validator.validate_schema_only(personality_dict)
```

### `get_validation_report(personality: Union[Dict[str, Any], str, Path]) -> Dict[str, Any]`

Genera un reporte detallado de validación.

**Parámetros:**
- `personality`: Personalidad a validar

**Retorna:**
- `Dict[str, Any]`: Reporte con detalles de validación

**Ejemplo:**
```python
report = validator.get_validation_report("mi_personalidad.json")

print(f"Válida: {report['valid']}")
print(f"Calidad: {report['quality_score']:.1%}")
print(f"Seguridad: {report['safety_score']:.1%}")

if not report['valid']:
    for error in report['errors']:
        print(f"Error: {error}")
```

## PersonalityCompiler

### `PersonalityCompiler()`

Inicializa el compilador de personalidades.

**Ejemplo:**
```python
from luminoracore.tools.compiler import PersonalityCompiler

compiler = PersonalityCompiler()
```

### `compile(personality: Dict[str, Any], provider: str, **kwargs) -> str`

Compila una personalidad para un proveedor específico.

**Parámetros:**
- `personality` (Dict): Personalidad a compilar
- `provider` (str): Proveedor objetivo
- `**kwargs`: Parámetros adicionales

**Retorna:**
- `str`: Prompt compilado

**Excepciones:**
- `ValueError`: Si el proveedor no es soportado

**Ejemplo:**
```python
prompt = compiler.compile(personality, "openai")
```

### `get_supported_providers() -> List[str]`

Retorna la lista de proveedores soportados.

**Retorna:**
- `List[str]`: Lista de nombres de proveedores

**Ejemplo:**
```python
providers = compiler.get_supported_providers()
print(f"Proveedores: {providers}")
```

### `validate_provider(provider: str) -> bool`

Valida si un proveedor es soportado.

**Parámetros:**
- `provider` (str): Nombre del proveedor

**Retorna:**
- `bool`: True si es soportado

**Ejemplo:**
```python
if compiler.validate_provider("openai"):
    prompt = compiler.compile(personality, "openai")
```

## PersonalityBlender

### `PersonalityBlender()`

Inicializa el blender de personalidades.

**Ejemplo:**
```python
from luminoracore.tools.blender import PersonalityBlender

blender = PersonalityBlender()
```

### `blend(personalities: Dict[str, Dict[str, Any]], blend_config: Dict[str, float]) -> Dict[str, Any]`

Mezcla múltiples personalidades según los pesos especificados.

**Parámetros:**
- `personalities` (Dict): Diccionario con personalidades a mezclar
- `blend_config` (Dict): Diccionario con nombres y pesos de personalidades

**Retorna:**
- `Dict[str, Any]`: Personalidad mezclada

**Excepciones:**
- `ValueError`: Si los pesos son inválidos o hay personalidades faltantes

**Ejemplo:**
```python
personalities = {
    "dr_luna": personality1,
    "capitan_garfio": personality2
}

blend_config = {
    "dr_luna": 0.6,
    "capitan_garfio": 0.4
}

blended = blender.blend(personalities, blend_config)
```

## Compiladores Específicos

### OpenAICompiler

Compilador optimizado para modelos de OpenAI.

```python
from luminoracore.compilers import OpenAICompiler

compiler = OpenAICompiler()
prompt = compiler.compile(personality)
```

### AnthropicCompiler

Compilador optimizado para modelos de Anthropic.

```python
from luminoracore.compilers import AnthropicCompiler

compiler = AnthropicCompiler()
prompt = compiler.compile(personality)
```

### LlamaCompiler

Compilador optimizado para modelos Llama.

```python
from luminoracore.compilers import LlamaCompiler

compiler = LlamaCompiler()
prompt = compiler.compile(personality)
```

### MistralCompiler

Compilador optimizado para modelos de Mistral.

```python
from luminoracore.compilers import MistralCompiler

compiler = MistralCompiler()
prompt = compiler.compile(personality)
```

### UniversalCompiler

Compilador universal compatible con cualquier proveedor.

```python
from luminoracore.compilers import UniversalCompiler

compiler = UniversalCompiler()
prompt = compiler.compile(personality)
```

## PersonalityLoader

### `PersonalityLoader(personalities_dir: Path)`

Inicializa el cargador de personalidades.

**Parámetros:**
- `personalities_dir` (Path): Directorio donde se encuentran las personalidades

**Ejemplo:**
```python
from luminoracore.personalities.loader import PersonalityLoader

loader = PersonalityLoader(Path("./personalities"))
```

### `load(name: str) -> Dict[str, Any]`

Carga una personalidad por nombre.

**Parámetros:**
- `name` (str): Nombre de la personalidad

**Retorna:**
- `Dict[str, Any]`: Personalidad cargada

**Excepciones:**
- `FileNotFoundError`: Si la personalidad no existe
- `json.JSONDecodeError`: Si el JSON es inválido

**Ejemplo:**
```python
personality = loader.load("dr_luna")
```

### `load_from_file(file_path: Union[str, Path]) -> Dict[str, Any]`

Carga una personalidad desde un archivo.

**Parámetros:**
- `file_path`: Ruta al archivo JSON

**Retorna:**
- `Dict[str, Any]`: Personalidad cargada

**Ejemplo:**
```python
personality = loader.load_from_file("personalities/dr_luna.json")
```

### `list_personalities() -> List[str]`

Lista todas las personalidades disponibles.

**Retorna:**
- `List[str]`: Lista de nombres de personalidades

**Ejemplo:**
```python
personalities = loader.list_personalities()
```

### `clear_cache()`

Limpia la caché de personalidades.

**Ejemplo:**
```python
loader.clear_cache()
```

### `reload(name: str) -> Dict[str, Any]`

Recarga una personalidad desde el archivo (ignora cache).

**Parámetros:**
- `name` (str): Nombre de la personalidad

**Retorna:**
- `Dict[str, Any]`: Personalidad recargada

**Ejemplo:**
```python
personality = loader.reload("dr_luna")
```

## Manejo de Errores

### Excepciones Comunes

#### `ValidationError`
Lanzada cuando una personalidad no cumple el schema JSON.

```python
from jsonschema.exceptions import ValidationError

try:
    validator.validate(invalid_personality)
except ValidationError as e:
    print(f"Error de validación: {e.message}")
```

#### `FileNotFoundError`
Lanzada cuando no se encuentra una personalidad.

```python
try:
    personality = pc.load_persona("nonexistent")
except FileNotFoundError as e:
    print(f"Personalidad no encontrada: {e}")
```

#### `ValueError`
Lanzada por errores de formato o parámetros inválidos.

```python
try:
    blended = pc.blend_personas({"invalid": 1.0})
except ValueError as e:
    print(f"Error de validación: {e}")
```

### Logging

LuminoraCore usa el módulo `logging` de Python para registrar información.

```python
import logging

# Configurar nivel de logging
logging.basicConfig(level=logging.INFO)

# Los logs aparecerán automáticamente
pc = PersonaCore()
```

## Ejemplos de Uso Avanzado

### Personalización de Compiladores

```python
from luminoracore.compilers import OpenAICompiler

# Crear compilador personalizado
class CustomOpenAICompiler(OpenAICompiler):
    def __init__(self):
        super().__init__()
        self.max_tokens = 6000  # Límite personalizado
    
    def compile(self, personality, **kwargs):
        # Lógica personalizada
        prompt = super().compile(personality, **kwargs)
        # Modificar prompt si es necesario
        return prompt
```

### Validación Personalizada

```python
from luminoracore.tools.validator import PersonalityValidator

class CustomValidator(PersonalityValidator):
    def _validate_custom_rules(self, personality):
        # Agregar validaciones personalizadas
        if "custom_field" not in personality:
            raise ValueError("Campo personalizado requerido")
```

### Blending Avanzado

```python
# Mezclar múltiples personalidades con pesos dinámicos
personalities = {
    "scientific": pc.load_persona("dr_luna"),
    "adventurous": pc.load_persona("capitan_garfio"),
    "caring": pc.load_persona("abuela_esperanza")
}

# Ajustar pesos según el contexto
def create_contextual_personality(context):
    if context == "education":
        weights = {"scientific": 0.7, "caring": 0.3}
    elif context == "entertainment":
        weights = {"adventurous": 0.6, "scientific": 0.4}
    else:
        weights = {"scientific": 0.4, "adventurous": 0.3, "caring": 0.3}
    
    return pc.blend_personas(weights)
```
