# Guía de Inicio Rápido

Esta guía te ayudará a comenzar con LuminoraCore en menos de 10 minutos.

## Instalación

### Requisitos
- Python 3.8 o superior
- pip (gestor de paquetes de Python)

### Instalación Básica

```bash
# Instalar desde PyPI (cuando esté disponible)
pip install luminoracore

# O instalar desde el código fuente
git clone https://github.com/luminoracore/luminoracore.git
cd luminoracore
pip install -e .
```

### Verificar Instalación

```bash
luminora --version
```

Deberías ver algo como: `LuminoraCore v1.0.0`

## Primeros Pasos

### 1. Explorar Personalidades Disponibles

```bash
luminora list
```

Esto mostrará todas las personalidades disponibles con información básica.

### 2. Obtener Información de una Personalidad

```bash
luminora info dr_luna
```

Verás información detallada sobre la personalidad Dr. Luna.

### 3. Compilar una Personalidad

```bash
# Compilar para OpenAI
luminora compile dr_luna openai

# Compilar y guardar en archivo
luminora compile dr_luna openai --output mi_prompt.txt

# Ver el prompt compilado
luminora compile dr_luna openai --show
```

### 4. Validar una Personalidad

```bash
# Validar todas las personalidades
luminora validate personalities/*.json

# Validación detallada
luminora validate personalities/dr_luna.json --detailed
```

## Uso Básico en Python

### Cargar y Usar una Personalidad

```python
from luminoracore import PersonaCore

# Inicializar
pc = PersonaCore()

# Cargar personalidad
personality = pc.load_persona("dr_luna")

# Compilar para OpenAI
prompt = pc.compile_for("openai", personality)

print(prompt)
```

### Integración con OpenAI

```python
import openai
from luminoracore import PersonaCore

# Configurar OpenAI
openai.api_key = "tu-api-key"

# Cargar personalidad
pc = PersonaCore()
personality = pc.load_persona("dr_luna")
system_prompt = pc.compile_for("openai", personality)

# Crear conversación
messages = [
    {"role": "system", "content": system_prompt},
    {"role": "user", "content": "¿Qué es la física cuántica?"}
]

# Enviar a OpenAI
response = openai.chat.completions.create(
    model="gpt-4",
    messages=messages
)

print(response.choices[0].message.content)
```

## Mezclar Personalidades (PersonaBlend™)

### Mezclar desde CLI

```bash
# Mezclar Dr. Luna (60%) con Capitán Garfio (40%)
luminora blend "dr_luna:0.6,capitan_garfio:0.4" --output hibrida.json
```

### Mezclar desde Python

```python
from luminoracore import PersonaCore

pc = PersonaCore()

# Configurar mezcla
blend_config = {
    "dr_luna": 0.6,      # 60% Dr. Luna
    "capitan_garfio": 0.4  # 40% Capitán Garfio
}

# Mezclar personalidades
hybrid = pc.blend_personas(blend_config)

# Compilar la personalidad mezclada
prompt = pc.compile_for("openai", hybrid)
```

## Chat Interactivo

### Demo de Chat

```bash
# Iniciar chat con Dr. Luna
luminora chat dr_luna

# Chat con proveedor específico
luminora chat dr_luna --provider anthropic
```

**Nota**: El chat actual es un demo. Para uso real, integra con tu proveedor de LLM preferido.

## Crear una Nueva Personalidad

### Desde Template

```bash
# Crear personalidad interactiva
luminora init "Mi Personalidad" --interactive

# Crear personalidad básica
luminora init "Mi Personalidad" --output-dir ./mis_personas
```

### Manualmente

1. Copia el template:
```bash
cp personalities/_template.json personalities/mi_personalidad.json
```

2. Edita el archivo JSON

3. Valida tu personalidad:
```bash
luminora validate personalities/mi_personalidad.json
```

## Ejemplos Completos

### Ejemplo 1: Asistente Educativo

```python
from luminoracore import PersonaCore

pc = PersonaCore()

# Mezclar personalidades educativas
blend_config = {
    "dr_luna": 0.7,        # 70% científica
    "prof_rigoberto": 0.3   # 30% profesor estricto
}

educational_ai = pc.blend_personas(blend_config)
prompt = pc.compile_for("openai", educational_ai)

# Usar en tu aplicación educativa
print(prompt)
```

### Ejemplo 2: Soporte al Cliente

```python
# Personalidad para soporte
support_blend = {
    "victoria_sterling": 0.5,  # 50% profesional
    "abuela_esperanza": 0.5    # 50% empática
}

support_ai = pc.blend_personas(support_blend)
prompt = pc.compile_for("anthropic", support_ai)
```

## Próximos Pasos

1. **Explora las personalidades**: Usa `luminora list` y `luminora info` para conocer todas las opciones
2. **Experimenta con mezclas**: Combina diferentes personalidades para crear híbridos únicos
3. **Integra con tu LLM**: Usa los prompts compilados con tu proveedor preferido
4. **Crea personalidades**: Desarrolla personalidades específicas para tu caso de uso
5. **Contribuye**: Envía nuevas personalidades o mejoras al proyecto

## Recursos Adicionales

- [Formato de Personalidades](personality_format.md) - Guía detallada del formato JSON
- [API Reference](api_reference.md) - Documentación completa de la API
- [Mejores Prácticas](best_practices.md) - Consejos para crear personalidades de calidad
- [Contributing Guide](contributing_guide.md) - Cómo contribuir al proyecto

## Soporte

- **Issues**: [GitHub Issues](https://github.com/luminoracore/luminoracore/issues)
- **Discusiones**: [GitHub Discussions](https://github.com/luminoracore/luminoracore/discussions)
- **Discord**: [LuminoraCore Community](https://discord.gg/luminoracore)

¡Felicidades! Ya conoces lo básico de LuminoraCore. ¡Es hora de crear personalidades increíbles! 🚀
