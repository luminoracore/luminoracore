# API Reference

This document provides comprehensive API reference for the LuminoraCore SDK Python.

## Table of Contents

- [Client](#client)
- [Personality Management](#personality-management)
- [Session Management](#session-management)
- [Provider Configuration](#provider-configuration)
- [Storage Configuration](#storage-configuration)
- [Memory Configuration](#memory-configuration)
- [Types](#types)

## Client

### LuminoraCoreClient

The main client class for interacting with LuminoraCore.

```python
from luminoracore import LuminoraCoreClient
from luminoracore.types.session import StorageConfig, MemoryConfig

client = LuminoraCoreClient(
    storage_config=StorageConfig(storage_type="memory"),
    memory_config=MemoryConfig()
)
```

#### Methods

##### `initialize() -> None`
Initialize the client and all its components.

##### `cleanup() -> None`
Clean up resources and close connections.

##### `load_personality(name: str, data: Dict[str, Any]) -> None`
Load a personality into the client.

**Parameters:**
- `name`: Personality name
- `data`: Personality data dictionary

##### `get_personality(name: str) -> Optional[PersonalityData]`
Get a personality by name.

**Returns:** Personality data or None if not found

##### `blend_personalities(personality_names: List[str], weights: List[float], blend_name: str) -> PersonalityData`
Blend multiple personalities.

**Parameters:**
- `personality_names`: List of personality names to blend
- `weights`: List of blend weights
- `blend_name`: Name for the blended personality

**Returns:** Blended personality data

##### `create_session(personality_name: str, provider_config: ProviderConfig) -> str`
Create a new session.

**Parameters:**
- `personality_name`: Name of the personality to use
- `provider_config`: Provider configuration

**Returns:** Session ID

##### `send_message(session_id: str, message: str, **kwargs) -> ChatResponse`
Send a message to a session.

**Parameters:**
- `session_id`: Session ID
- `message`: User message
- `**kwargs`: Additional parameters

**Returns:** Chat response

##### `stream_message(session_id: str, message: str, **kwargs) -> AsyncGenerator[ChatResponse, None]`
Stream a message to a session.

**Parameters:**
- `session_id`: Session ID
- `message`: User message
- `**kwargs`: Additional parameters

**Yields:** Chat response chunks

##### `get_conversation(session_id: str) -> Optional[Conversation]`
Get conversation for a session.

**Parameters:**
- `session_id`: Session ID

**Returns:** Conversation or None if not found

##### `store_memory(session_id: str, key: str, value: Any) -> None`
Store memory for a session.

**Parameters:**
- `session_id`: Session ID
- `key`: Memory key
- `value`: Memory value

##### `get_memory(session_id: str, key: str) -> Any`
Get memory for a session.

**Parameters:**
- `session_id`: Session ID
- `key`: Memory key

**Returns:** Memory value or None if not found

## Personality Management

### PersonalityData

Represents a personality configuration.

```python
from luminoracore.types.personality import PersonalityData

personality = PersonalityData(
    name="helpful_assistant",
    description="A helpful AI assistant",
    system_prompt="You are a helpful AI assistant.",
    metadata={}
)
```

#### Fields

- `name: str` - Personality name
- `description: str` - Personality description
- `system_prompt: str` - System prompt for the personality
- `name_override: Optional[str]` - Override for display name
- `description_override: Optional[str]` - Override for display description
- `metadata: Dict[str, Any]` - Additional metadata

### PersonalityBlend

Represents a personality blend configuration.

```python
from luminoracore.types.personality import PersonalityBlend

blend = PersonalityBlend(
    personalities=[personality1, personality2],
    weights=[0.6, 0.4],
    blend_type="weighted"
)
```

#### Fields

- `personalities: List[PersonalityData]` - Personalities to blend
- `weights: List[float]` - Blend weights for each personality
- `blend_type: str` - Type of blending
- `custom_rules: Optional[Dict[str, Any]]` - Custom blending rules

## Session Management

### SessionConfig

Configuration for personality sessions.

```python
from luminoracore.types.session import SessionConfig, SessionType

config = SessionConfig(
    session_id="session_123",
    personality={"name": "helpful_assistant"},
    provider_config={"name": "openai"},
    session_type=SessionType.CHAT,
    max_history=100,
    timeout=300
)
```

#### Fields

- `session_id: str` - Unique session identifier
- `personality: Dict[str, Any]` - Personality configuration
- `provider_config: Dict[str, Any]` - Provider configuration
- `session_type: SessionType` - Type of session
- `max_history: int` - Maximum conversation history length
- `timeout: int` - Session timeout in seconds

### Conversation

Represents a conversation with messages and metadata.

```python
from luminoracore.types.session import Conversation, Message, MessageRole
from datetime import datetime

conversation = Conversation(
    session_id="session_123",
    messages=[
        Message(
            role=MessageRole.USER,
            content="Hello!",
            timestamp=datetime.utcnow()
        )
    ]
)
```

#### Fields

- `session_id: str` - Session identifier
- `messages: List[Message]` - List of messages
- `metadata: Dict[str, Any]` - Conversation metadata
- `created_at: datetime` - Creation timestamp
- `updated_at: datetime` - Last update timestamp

## Provider Configuration

### ProviderConfig

Configuration for LLM providers.

```python
from luminoracore.types.provider import ProviderConfig

config = ProviderConfig(
    name="openai",
    api_key="your-api-key",
    model="gpt-3.5-turbo",
    base_url="https://api.openai.com/v1",
    extra={"timeout": 30, "max_retries": 3}
)
```

#### Fields

- `name: str` - Provider name
- `api_key: str` - API key
- `model: str` - Model name
- `base_url: Optional[str]` - Base URL for the API
- `extra: Optional[Dict[str, Any]]` - Additional configuration

### Supported Providers

- **OpenAI**: `openai`
- **Anthropic**: `anthropic`
- **Mistral**: `mistral`
- **Cohere**: `cohere`
- **Google**: `google`
- **Llama**: `llama`

## Storage Configuration

### StorageConfig

Configuration for conversation storage.

```python
from luminoracore.types.session import StorageConfig, StorageType

# In-memory storage
config = StorageConfig(storage_type=StorageType.MEMORY)

# Redis storage
config = StorageConfig(
    storage_type=StorageType.REDIS,
    connection_string="redis://localhost:6379"
)

# PostgreSQL storage
config = StorageConfig(
    storage_type=StorageType.POSTGRES,
    connection_string="postgresql://user:password@localhost/db"
)

# MongoDB storage
config = StorageConfig(
    storage_type=StorageType.MONGODB,
    connection_string="mongodb://localhost:27017/db"
)
```

#### Fields

- `storage_type: StorageType` - Type of storage backend
- `connection_string: Optional[str]` - Connection string
- `table_name: str` - Table name for database storage
- `auto_create_tables: bool` - Whether to auto-create tables
- `encryption_enabled: bool` - Whether encryption is enabled
- `compression_enabled: bool` - Whether compression is enabled

## Memory Configuration

### MemoryConfig

Configuration for conversation memory.

```python
from luminoracore.types.session import MemoryConfig

config = MemoryConfig(
    enabled=True,
    max_entries=1000,
    decay_factor=0.1,
    importance_threshold=0.5,
    track_topics=True,
    track_preferences=True,
    track_context=True,
    track_emotions=False
)
```

#### Fields

- `enabled: bool` - Whether memory is enabled
- `max_entries: int` - Maximum number of memory entries
- `decay_factor: float` - Memory decay factor
- `importance_threshold: float` - Importance threshold for memory
- `track_topics: bool` - Whether to track topics
- `track_preferences: bool` - Whether to track preferences
- `track_context: bool` - Whether to track context
- `track_emotions: bool` - Whether to track emotions

## Types

### Enums

#### SessionType
- `STATEFUL` - Stateful session
- `STATELESS` - Stateless session
- `CHAT` - Chat session

#### MessageRole
- `USER` - User message
- `ASSISTANT` - Assistant message
- `SYSTEM` - System message

#### StorageType
- `MEMORY` - In-memory storage
- `REDIS` - Redis storage
- `POSTGRES` - PostgreSQL storage
- `MONGODB` - MongoDB storage
- `FILE` - File storage

### ChatMessage

Represents a chat message.

```python
from luminoracore.types.provider import ChatMessage

message = ChatMessage(
    role="user",
    content="Hello!"
)
```

### ChatResponse

Represents a chat response.

```python
from luminoracore.types.provider import ChatResponse

response = ChatResponse(
    content="Hello! How can I help you?",
    role="assistant",
    finish_reason="stop",
    usage={"prompt_tokens": 10, "completion_tokens": 20},
    model="gpt-3.5-turbo"
)
```

## Error Handling

The SDK uses custom exceptions for error handling:

- `PersonalityError` - Personality-related errors
- `SessionError` - Session-related errors
- `ProviderError` - Provider-related errors
- `StorageError` - Storage-related errors

```python
from luminoracore.utils.exceptions import PersonalityError, SessionError

try:
    await client.load_personality("invalid", {})
except PersonalityError as e:
    print(f"Personality error: {e}")

try:
    await client.send_message("invalid_session", "Hello")
except SessionError as e:
    print(f"Session error: {e}")
```
